<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function index(){
    	return  redirect()->route('login');
    }

    public function login(Request $request)
    {
    	# code...
    }
}
