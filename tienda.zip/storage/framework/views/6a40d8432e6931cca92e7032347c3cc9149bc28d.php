

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/landing-page.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div id="contenedor">      
    <div class="content_productos">
      <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="panel_product border">
          <a href="<?php echo e(route('shop.show',  $lista['id'])); ?>">
            <div class="panel_product_img ">
              <div class="product_img">
                <img src="<?php echo e(asset( '/storage/'. $lista['image'])); ?>">
              </div>
            </div>
            <div class="panel_product_info ">
              <div class="product_info">
                <div class="product-name"><?php echo e($lista['nombre']); ?></div>
                <div class="product-precio">$<?php echo e($lista['precio']); ?></div>
              </div>                   
            </div>                 
          </a>
        </div>
        <script type="text/javascript">
          
        </script>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
    </div>       
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tienda\resources\views/search-results.blade.php ENDPATH**/ ?>