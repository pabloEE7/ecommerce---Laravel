

<?php $__env->startSection('meta'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
<title>pay_cart</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/cart.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content_">
    <div class="panel_global">
        <div class="container pt-5  pb-5">
            <form action="<?php echo e(action('CartController@pay')); ?>" method="POST">

                <h3 class="pt-3 pb-3">Datos de envio</h3>
                <div class="form-row">        
                    <div class="form-group  col-md-4">
                        <label for="inputAddress">Pais</label>
                        <input type="text" class="form-control" id="inputAddress" placeholder="pais">
                    </div>
                    <div class="form-group  col-md-4">
                        <label for="inputAddress2">Provincia</label>
                        <input type="text" class="form-control" id="inputAddress2" placeholder="Provincia">
                    </div>
                    <div class="form-group  col-md-4">
                        <label for="inputAddress2">Codigo Posta</label>
                        <input type="text" class="form-control" id="inputAddress2" placeholder="Codigo postal">
                    </div>
                    <div class="form-group  col-md-6">
                        <label for="inputAddress2">Calle</label>
                        <input type="text" class="form-control" id="inputAddress2" placeholder="calle">
                    </div>
                    <div class="form-group  col-md-6">
                        <label for="inputAddress2">Barrio</label>
                        <input type="text" class="form-control" id="inputAddress2" placeholder="Barrio (opcional)">
                    </div>
                    <div class="form-group  col-md-4">
                        <label for="inputAddress2">Numero</label>
                        <input type="text" class="form-control" id="inputAddress2" placeholder="Numero">
                    </div>
                    <div class="form-group  col-md-8">
                        <label for="inputAddress2">Departamento</label>
                        <input type="text" class="form-control" id="inputAddress2" placeholder="Departamento (opcional)">
                    </div>
                </div>     
                <script
                    src="https://www.mercadopago.com.ar/integrations/v1/web-payment-checkout.js"
                    data-preference-id="<?php echo e($preference_id); ?>">
                </script>
            </form>

            <div class="pt-4">
                <ul>
                    <p>Ejemplo de test proporcionado por mercado pago:</p>
                    <li>Tarjeta de credito: 5031 7557 3453 0604</li>
                    <li>CVV: 123</li>
                    <li>Fecha de vencimiento: 11/25</li>
                </ul>     
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tienda\resources\views/pay_cart.blade.php ENDPATH**/ ?>