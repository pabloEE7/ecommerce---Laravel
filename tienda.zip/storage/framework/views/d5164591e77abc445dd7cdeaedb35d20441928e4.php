


<?php $__env->startSection('meta'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
<title>carrito de compras ecommerce</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/cart.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content_">
	<div class="panel_global">
		<?php if(!session('cart')): ?>
	        <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
	        	<div class="alert alert-danger" role="alert">
                    El carrito esta vacio!
                </div>
	        </div>
	    <?php else: ?>	        
	        <div class="text-right">
	            <div class=" p-3">
	            	<form action="<?php echo e(action('CartController@deleteCartAll')); ?>" method="GET">
	            		<button type="buttom" class="btn btn-outline-dark p-4 rounded-0">Vaciar carrito</button>
	            	</form>	            	
	            </div>	            		
	        </div>
	        <div class="container pt-5 pb-5">
	            <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            	<div class="content_item row pt-4">
	            		<div class="col-6 d-flex">
	            			<div class="item_img ">
	            				<img src="<?php echo e(asset( '/storage/'. $lista['image'])); ?>">
	            			</div>
	            			<div class=" pl-2 ">
	            				<p><?php echo e($lista['nombre']); ?></p>
	                            <p>$<?php echo e($lista['precio_u']); ?> x<?php echo e($lista['cantidad']); ?></p>
	            			</div>	                        	            			
	            		</div>
	            		<div class="col-6 d-flex  justify-content-end">	            			
	            			<p class="item_precio ">$<?php echo e($lista['precio']); ?></p>
	            			<div class="item_delete">
	            				<form action="<?php echo e(route('cart.delete', $lista['id'])); ?>" method="GET">
	            		            <button type="buttom" class="">x</button>
	            	            </form>		            				
	            			</div>	                                               
	            		</div>	            			        
	            	</div>
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
	            <div class="content_botones m-auto">
	                <a  href="<?php echo e(route('landing-page.index')); ?>">
	                	<button class="btn button rounded-0 mt-5">Continuar comprando</button>
	                </a>
	                <div class="cont_compra">
	                	<form  action="<?php echo e(action('CartController@pay_cart')); ?>" method="POST">		
	                		<input type="submit" name="submit"  class="btn button-primary rounded-0 mt-5" value="Procesar compra">	                	    
	                    </form>
	                </div>	                
                </div>                    	        	
	        </div>
	    <?php endif; ?>
	</div>	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tienda\resources\views/cart.blade.php ENDPATH**/ ?>