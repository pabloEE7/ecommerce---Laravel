
<?php $__env->startSection('content'); ?>
<div class="container p-5">
	<p>cadetes</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tienda\resources\views/cadetes/index.blade.php ENDPATH**/ ?>