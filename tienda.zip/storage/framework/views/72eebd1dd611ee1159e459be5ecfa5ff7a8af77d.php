
<?php $__env->startSection('content'); ?>
<div class="container p-5">
	<p>pedidos actuales</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tienda\resources\views/pedidos/actuales.blade.php ENDPATH**/ ?>