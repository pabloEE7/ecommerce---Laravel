

<?php $__env->startSection('meta'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
<title>procesar_compra</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/cart.css')); ?>" />
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="content_">
	<div class="panel_global row ">
      <div class="col-9 m-auto p-5">
        <form  action="https://api.mercadolibre.com/sites/MLA/shipping_options?zip_code_from=5000&zip_code_to=5000&dimensions=70x70x70,70" method="GET">
            <input type="text" name="zip_code_from"  value="5000">
            <input type="hidden" name="zip_code_to" value="5000">
            <input type="hidden" name="dimensions" value="70x70x70,70">
	        <input type="submit" name=""  class="btn btn-outline-dark" value="calcular envio">
        </form>
      </div>
          
<div class="col-8 m-auto">
	<form  action="<?php echo e(action('CartController@pay_cart')); ?>" method="POST">
    <h3>Datos de envio</h3>
    <h5>Datos del destinatario</h5>	    
  <div class="form-row">    	
    <div class="form-group col-md-6">
      <label for="inputEmail4">Nombre</label>
      <input type="email" class="form-control" id="inputEmail4">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Apellido</label>
      <input type="password" class="form-control" id="inputPassword4">
    </div>
    <div class="form-group col-md-12">
      <label for="inputPassword4">Telefono</label>
      <input type="password" class="form-control" id="inputPassword4">
    </div>
    <div class="form-group col-md-12">
      <label for="inputPassword4">Email</label>
      <input type="password" class="form-control" id="inputPassword4">
    </div>
  </div>

  <h5>Domicilio del destinatario</h5>
  <div class="form-row">        
  <div class="form-group  col-md-12">
    <label for="inputAddress">Pais</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="pais">
  </div>
  <div class="form-group  col-md-12">
    <label for="inputAddress2">Calle</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="calle">
  </div>
  <div class="form-group  col-md-4">
    <label for="inputAddress2">Numero</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Numero">
  </div>
  <div class="form-group  col-md-8">
    <label for="inputAddress2">Departamento</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Departamento (opcional)">
  </div>
  <div class="form-group  col-md-12">
    <label for="inputAddress2">Barrio</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Barrio (opcional)">
  </div>
  <div class="form-group  col-md-12">
    <label for="inputAddress2">Ciudad</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Ciudad">
  </div>
  <div class="form-group  col-md-12">
    <label for="inputAddress2">Provincia</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Provincia">
  </div>
  <div class="form-group  col-md-12">
    <label for="inputAddress2">Codigo Posta</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Codigo postal">
  </div>

  </div>

  <h5>Domicilio de facturacion</h5>
  <div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputCity">DNI o CUIL</label>
      <input type="text" class="form-control" id="inputCity">
    </div>    
  </div>

  <div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Check me out
      </label>
    </div>
  </div>


    <script
        src="https://www.mercadopago.com.ar/integrations/v1/web-tokenize-checkout.js"
        data-public-key="TEST-838beeda-cea7-4f69-a222-ef768e29d205"
        data-summary-product-label="mercadopago"
        data-transaction-amount="100.00">
    </script>
  
  
  </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tienda\resources\views/procesar_compra.blade.php ENDPATH**/ ?>