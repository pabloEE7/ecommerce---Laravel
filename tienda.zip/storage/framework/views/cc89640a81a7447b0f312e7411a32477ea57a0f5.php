<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container p-5">
    <div class="row">
        <div class="content-general paneles-white sombra-1 titulos col-12 mt-5 text-center">
            <h3>Pedidos pendientes</h3>
        </div>
        <div class="col-6">
            <div class="content-general paneles-white sombra-1 titulos col-12  mt-5  text-center">
                <h3>Pedidos tomados</h3>
            </div>
        </div>
        <div class="col-6">
            <div class="content-general paneles-white sombra-1 titulos col-12  mt-5  text-center">
                <h3>Pedidos entregados</h3>
            </div>
        </div>
        
        <div class="content-general paneles-white sombra-1 titulos col-12  mt-5  text-center">
            <h3>Cadetes activos</h3>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tienda\resources\views/home.blade.php ENDPATH**/ ?>