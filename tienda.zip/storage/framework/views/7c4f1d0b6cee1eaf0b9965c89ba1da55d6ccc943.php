<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Bienvenido a planB Delivery</title>

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/landing.css')); ?>" />
</head>
<body>
	<a  href="<?php echo e(route('home')); ?>">
		<button class="button">Ingresar</button>
	</a>	
	

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\tienda\resources\views/landing/index.blade.php ENDPATH**/ ?>