

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/shop.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="content_">
    <div class="content_blogal">
        <div class="panel_ row pt-5">
            <div class=" col-md-6">
                <div class="content_image_select">
                    <div class="image_select">
                      <img src="<?php echo e(asset( '/storage/'. $imagenes[0]->nombre)); ?>" class="img-fluid" id="currentImage">
                    </div>
                </div>
                <div class="content_images">
                  <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
                    <div class="images product-section-thumbnail">
                      <img src="<?php echo e(asset( '/storage/'. $lista->nombre)); ?>" class="img-fluid rounded d-block">
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>              
            </div>
            
            <div class=" col-md-6 pb-4">
                <div class="panel_product col-11 ">
                    <h1><?php echo e($productos->nombre); ?></h1>
                      <form action="<?php echo e(action('CartController@store')); ?>" method="GET">             
                        <label class="p-info">$<i id="shop_precio"><?php echo e($productos->precio); ?></i></label>
                        <div class="">
                            <div class="form-group form-inline">                              
                                <label for="shop_cantidad">Cantidad</label>
                                <input type="text" name="cantidad"  id="shop_cantidad" class="form-control ml-2" value="1" style="width: 70px; text-align: center;">                    
                            </div>
                        </div>                    
                        <div class="botones_pago row">                               
                        </div>                    
                      <input type="hidden" name="id" value="<?php echo e($productos->id); ?>"> 
                      <input type="hidden" name="precio" id="shop_precio_input" value="<?php echo e($productos->precio); ?>">
                      <input type="hidden" name="precio_u" value="<?php echo e($productos->precio); ?>">

                      <input type="submit" value="Agregar al carrito" class="button button-plain">
                    </form>                                      
                </div>                  
            </div>
        </div>
      <hr class=""> 
      <div>
        <h3>Descripcion</h3>
        <p class="p-info">asd</p>
      </div>        
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script type="text/javascript">
   
    $("#shop_cantidad").on("keyup", function() {

        let precio = "<?php echo e($productos->precio); ?>";
        let cantidad = $("#shop_cantidad").val();
            
        if (cantidad == "" || cantidad == 0){

            $('#shop_precio').html("<?php echo e($productos->precio); ?>");
        $('#shop_precio_input').val("<?php echo e($productos->precio); ?>");
                        
        }else{

            precio *= cantidad;

            $('#shop_precio').html(precio);
        $('#shop_precio_input').val(precio);
        }

    });

    $( "#shop_cantidad" ).blur(function() {

      let cantidad = $("#shop_cantidad").val();
      let cantidad_input = $("#shop_cantidad_input");

      if ( cantidad == "" || cantidad == 0) {

        $('#shop_cantidad').val(1);
        
      }
    });

    (function(){

      const currentImage = document.querySelector('#currentImage');
      const images = document.querySelectorAll('.product-section-thumbnail');
      images.forEach((element) => element.addEventListener('click', thumbnailClick));
      function thumbnailClick(e) {
        currentImage.src = this.querySelector('img').src;               
      }
    })();

  </script>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tienda\resources\views/shop.blade.php ENDPATH**/ ?>