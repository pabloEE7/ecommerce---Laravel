@extends('layouts/page')
@section('content')
<div class="container p-5">
	<p>comercios</p>
</div>
@endsection