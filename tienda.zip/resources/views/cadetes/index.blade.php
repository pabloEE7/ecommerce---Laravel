@extends('layouts/page')
@section('content')
<div class="container p-5">
	<p>cadetes</p>
</div>
@endsection